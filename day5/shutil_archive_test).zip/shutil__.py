#-*- coding:utf-8 -*-
#  @Author  :pororo
#  @Time    :2020-04-30 下午 14:27
#  @Note    :
import shutil
# f1= open("test.py",encoding="utf-8")
# # f2= open("test2.py","w",encoding="utf-8")
# #
# #
# # shutil.copyfileobj(f1,f2)

shutil.copyfile("test2.py","test3.py")
shutil.make_archive("shutil_archive_test)","zip","D:\workspace\python\pororo\study\day5_1")